var indexSectionsWithContent =
{
  0: "abcdefgilnprstuvw~",
  1: "ab",
  2: "b",
  3: "abcdefgilnprstuvw~",
  4: "cegps",
  5: "ae",
  6: "aer",
  7: "e",
  8: "c",
  9: "e",
  10: "a"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "related",
  9: "groups",
  10: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Friends",
  9: "Modules",
  10: "Pages"
};

